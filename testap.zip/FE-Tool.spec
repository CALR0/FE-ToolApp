# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all, collect_data_files

# Recolectar datos y binarios de librerías que PyInstaller no detecta solas
datas_pdfplumber,    binaries_pdfplumber,    hiddens_pdfplumber    = collect_all('pdfplumber')
datas_pdfminer,      binaries_pdfminer,      hiddens_pdfminer      = collect_all('pdfminer')
datas_pandas,        binaries_pandas,        hiddens_pandas        = collect_all('pandas')
datas_openpyxl,      binaries_openpyxl,      hiddens_openpyxl      = collect_all('openpyxl')
datas_requests,      binaries_requests,      hiddens_requests      = collect_all('requests')
datas_certifi,       binaries_certifi,       hiddens_certifi       = collect_all('certifi')

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=(
        binaries_pdfplumber +
        binaries_pdfminer   +
        binaries_pandas     +
        binaries_openpyxl   +
        binaries_requests   +
        binaries_certifi
    ),
    datas=(
        [('icono.ico', '.')] +
        datas_pdfplumber +
        datas_pdfminer   +
        datas_pandas     +
        datas_openpyxl   +
        datas_requests   +
        datas_certifi
    ),
    hiddenimports=(
        hiddens_pdfplumber +
        hiddens_pdfminer   +
        hiddens_pandas     +
        hiddens_openpyxl   +
        hiddens_requests   +
        hiddens_certifi    +
        [
            # Tkinter
            'tkinter',
            'tkinter.ttk',
            'tkinter.messagebox',
            'tkinter.filedialog',
            # Módulos del proyecto
            'config',
            'config.perfiles',
            'config.theme',
            'core',
            'core.xml_generator',
            'core.xml_transformer',
            'services',
            'services.rndc_service',
            'ui',
            'ui.app',
            'ui.excel_loader',
            'ui.rndc_uploader',
            'ui.consultar_remesas',
            'ui.editar_xml',
            'ui.reconstruir_xml',
            'ui.extraer_datos_rg',
            'ui.cruzar_remesas',
            'ui.corregir_remesa',
            'ui.anular_cumplido_remesa',
            'ui.cumplir_remesa',
            'ui.proceso_completo_remesa',
            'ui.anular_cumplido_manifiesto',
            'utils',
            'utils.helpers',
            # Multiprocessing (ProcessPoolExecutor en extraer_datos_rg)
            'multiprocessing',
            'concurrent.futures',
            # Extras comunes que PyInstaller pierde
            'xml.etree.ElementTree',
            'email.mime.text',
            'email.mime.multipart',
            'charset_normalizer',
            'urllib3',
            'idna',
        ]
    ),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Excluir lo que definitivamente no se usa para reducir tamaño
        'matplotlib',
        'scipy',
        'numpy.distutils',
        'IPython',
        'jupyter',
        'notebook',
        'pytest',
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='FE-Tool',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,          # UPX puede causar falsos positivos en antivirus — desactivado
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,      # Sin consola negra
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='icono.ico',   # Ícono del .exe en el explorador de Windows
)

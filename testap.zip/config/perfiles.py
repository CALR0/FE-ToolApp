NIT_UT        = "901101271"
NOMBRE_UT     = "UNION TEMPORAL AMERICAN LOGISTIC UT"
PREFIJO       = "41"
UNIDAD_MEDIDA = "KGM"

PERFILES = {
    "ut_tsp": {
        "nombre":        "UT Transportes Sánchez Polo",
        "nit_socio":     "8901031611",
        "nombre_socio":  "TRANSPORTES SANCHEZ POLO S.A.",
        "email_from":    "emisionfe@sanchezpolo.com",
        "email_contact_supplier": "facturacionelogia@daabon.com.co",
        "carpeta":       "FACTURAS_GENERADAS_TSP",
        "rndc_usuario":  "FELTSP@0137",
        "rndc_password": "feltsp12345",
        "rndc_usuario_corregir":  "CG_TSP@137",
        "rndc_password_corregir": "CTG123456789",
        "nit_ut":              "901101271",
        "nombre_ut":           "UNION TEMPORAL AMERICAN LOGISTIC UT",
        "carpeta_reconstruir": "FACTURAS_RECONSTRUIDAS_TSP",
        "nit_customer":        "800021308",
        "email_customer":      "facturacion@drummondltd.com",
        "telefono_customer":   "3135398327",
        "prefijo_remesa":      False,
    },
    "ut_elogia": {
        "nombre":        "UT Elogia",
        "nit_socio":     "8190041165",
        "nombre_socio":  "ELOGIA SOLUCIONES LOGISTICAS S.A.S",
        "email_from":    "emisionfe@sanchezpolo.com",
        "email_contact_supplier": "facturacionelogia@daabon.com.co",
        "carpeta":       "FACTURAS_GENERADAS_ELOGIA",
        "rndc_usuario":  "FACURAE@2120",
        "rndc_password": "FacturaElogia2024",
        "nit_ut":              "901101271",
        "nombre_ut":           "UNION TEMPORAL AMERICAN LOGISTIC UT",
        "carpeta_reconstruir": "FACTURAS_RECONSTRUIDAS_ELOGIA",
        "nit_customer":        "800021308",
        "email_customer":      "facturacion@drummondltd.com",
        "telefono_customer":   "3135398327",
        "prefijo_remesa":      True,
    },
}
